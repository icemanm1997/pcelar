from django.apps import AppConfig


class MagacinConfig(AppConfig):
    name = 'magacin'
