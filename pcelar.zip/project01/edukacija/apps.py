from django.apps import AppConfig


class EdukacijaConfig(AppConfig):
    name = 'edukacija'
